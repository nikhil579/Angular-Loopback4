export class RealEstate {
    id?: string
    companyName: string
    location: string
}
