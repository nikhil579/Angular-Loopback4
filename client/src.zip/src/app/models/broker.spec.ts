import { Broker } from './broker';

describe('Broker', () => {
  it('should create an instance', () => {
    expect(new Broker()).toBeTruthy();
  });
});
