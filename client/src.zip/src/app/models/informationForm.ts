export class InformationForm {
    gender: Array<String>
    occupation: Array<String>
    sector: Array<String>
    residenceType: Array<String>
    currResidence: Array<String>
    bookingPref: Array<String>
    budget: Array<String>
    possession: Array<String>
    purpose: Array<String>
    financeDetail: Array<String>
}