export class Note {
    id?: string
    title: string
    description: string
    author: string

}

