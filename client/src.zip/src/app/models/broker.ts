export class Broker {
    id?: string
    name: string
    email: string
    mobile: number
    companyName: string
    location: string
    Rera_Number?: string
    GST_Number?: string
    realEstateId: string
}
