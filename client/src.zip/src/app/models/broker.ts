export class Broker {

    name: string
    email: string
    company: string
    address: string
    additionalProp1: {}
}
