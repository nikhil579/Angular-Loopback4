export const gender = ['Male', 'Female','Other']
