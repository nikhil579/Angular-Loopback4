import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { UserInfo } from 'src/app/models/user-info';
import { UserDatabaseService } from 'src/app/services/user-database.service';
import Swal from 'sweetalert2';
import { gender } from './mydata';

@Component({
  selector: 'app-form-user',
  templateUrl: './form-user.component.html',
  styleUrls: ['./form-user.component.css']
})
export class FormUserComponent implements OnInit {
  userInfo: UserInfo = new UserInfo()
  userGender: Array<String> = gender
  userOccupation: Array<String> = ['Self Employed', 'Service', 'Other'];
  userSector: Array<String> = ['IT', 'Bank', 'Management', 'Other'];
  userResidence: Array<String> = ['Self-Owned', 'Rented'];
  userCurrentRes: Array<String> = ['1 BHK', '2 BHK', '3 BHK', 'Other'];
  userBookingPref: Array<String> = ['1 BHK', '2 BHK', '3 BHK'];
  userBudget: Array<String> = ['Below 50 Lac', '60 Lac', '70 Lac', '80 Lac', '90 Lac', '1 Cr & Above'];
  userPossession: Array<String> = ['Ready', '6 Months', '1 Year', '2 Years', '3 Years'];
  userPurpose: Array<String> = ['Investment', 'End Use', 'Both'];
  userFinance: Array<String> = ['Self Funding', 'Home Loan'];
  constructor(public databaseService: UserDatabaseService, private router: Router) { }
  ngOnInit(): void {
  }
  send(form: NgForm) {
    console.log(form.value);
    this.post(form)

  }
  post(form: NgForm) {
    this.databaseService.postUserInfo(form.value).subscribe(res => {
      console.log(res);
      Swal.fire(
        'User Created'
      )
      this.router.navigateByUrl('/')
    }, err => {
      console.error(err);
    }
    )
  }
}
